/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.mycompany.sistemagestion;

import com.mycompany.sistemagestion.forms.Formulario;

/**
 *
 * @author hugov
 */
public class Main {
    public static void main(String[] args) {
        Formulario ventana = new Formulario();
        ventana.show(); //mostrar formulario
    }
    
}
