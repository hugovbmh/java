package com.cursojava.curso.dao;

import com.cursojava.curso.models.Usuario;

import java.util.List;
// la clase que implemente esta interfaz, está obligada a usar estas funciones o metodos
// la interface UsuarioDao indica cómo se llamaran las funciones o metodos
public interface UsuarioDao {
    List<Usuario> getUsuarios(); //nombre de funciones sin {} al final
    void eliminar(Long id);

    void registrar(Usuario usuario);
    boolean verificarCredenciales(Usuario usuario);
}
