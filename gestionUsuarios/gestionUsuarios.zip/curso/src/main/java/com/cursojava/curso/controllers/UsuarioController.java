package com.cursojava.curso.controllers;

import com.cursojava.curso.dao.UsuarioDao;
import com.cursojava.curso.models.Usuario;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController //anotacion para controlador
public class UsuarioController {
    //inyeccion de dependencias
    //crea un objeto en UsuarioDaoImp y lo manda a esta variable
    @Autowired
    private UsuarioDao usuarioDao;

    //anotacion para request y (value = "URL")
    @RequestMapping(value = "api/usuarios/{id}") // la URL, y el metodo por defecto es GET
    public Usuario getUsuario(@PathVariable Long id){
        Usuario usuario = new Usuario();
        usuario.setId(id);;
        usuario.setNombre("Lucas");
        usuario.setApellido("Moy");
        usuario.setEmail("lucasmoy@hotmail.com");
        usuario.setTelefono("998437436");
        return usuario;
    }
    @RequestMapping(value = "api/usuarios", method = RequestMethod.POST) // la URL
    public void registrarUsuario(@RequestBody Usuario usuario){
        usuarioDao.registrar(usuario); //registrar usuario
    }
    @RequestMapping(value = "api/usuarios") // la URL
    public List<Usuario> getUsuarios(){
        return usuarioDao.getUsuarios(); //lista usuarios
    }

    @RequestMapping(value = "usuari4o") // la URL
    public Usuario editar(){
        Usuario usuario = new Usuario();
        usuario.setNombre("Lucas");
        usuario.setApellido("Moy");
        usuario.setEmail("lucasmoy@hotmail.com");
        usuario.setTelefono("998437436");
        return usuario;
    }
    @RequestMapping(value = "api/usuarios/{id}", method = RequestMethod.DELETE) // la URL
    public void eliminar(@PathVariable Long id){
    usuarioDao.eliminar(id);
    }
    @RequestMapping(value = "usuari2o") // la URL
    public Usuario buscar(){
        Usuario usuario = new Usuario();
        usuario.setNombre("Lucas");
        usuario.setApellido("Moy");
        usuario.setEmail("lucasmoy@hotmail.com");
        usuario.setTelefono("998437436");
        return usuario;
    }
}
